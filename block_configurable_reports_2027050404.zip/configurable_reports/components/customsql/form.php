<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Configurable Reports a Moodle block for creating customizable reports
 *
 * @copyright  2020 Juan Leyva <juan@moodle.com>
 * @package    block_configurable_reports
 * @author     Juan leyva <http://www.twitter.com/jleyvadelgado>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once($CFG->libdir . '/formslib.php');

/**
 * Class customsql_form
 *
 * @package   block_configurable_reports
 * @author    Juan leyva <http://www.twitter.com/jleyvadelgado>
 */
class customsql_form extends moodleform {

    // Based on Custom SQL Reports Plugin.
    // See http://moodle.org/mod/data/view.php?d=13&rid=2884.

    /**
     * Form definition
     */
    public function definition(): void {
        global $COURSE;

        $mform =& $this->_form;

        $mform->addElement('textarea', 'querysql', get_string('querysql', 'block_configurable_reports'), 'rows="35" cols="80"');
        $mform->addRule('querysql', get_string('required'), 'required', null, 'client');
        $mform->setType('querysql', PARAM_RAW);

        $mform->addElement('hidden', 'courseid', $COURSE->id);
        $mform->setType('courseid', PARAM_INT);

        $this->add_action_buttons();

        $mform->addElement('static', 'note', '', get_string('listofsqlreports', 'block_configurable_reports'));

        if ($userandrepo = get_config('block_configurable_reports', 'sharedsqlrepository')) {

            $github = new \block_configurable_reports\github;
            $github->set_repo($userandrepo);
            $res = $github->get('/contents');
            $res = json_decode($res);

            if (is_array($res)) {
                $reportcategories = [get_string('choose')];

                foreach ($res as $item) {
                    if ($item->type === 'dir') {
                        $reportcategories[$item->path] = $item->path;
                    }
                }

                $reportcatstr = get_string('reportcategories', 'block_configurable_reports');
                $mform->addElement('select', 'reportcategories', $reportcatstr, $reportcategories);

                // The reports are the ones in the chosen category, so the list starts out empty.
                $reportsincatstr = get_string('reportsincategory', 'block_configurable_reports');
                $mform->addElement('select', 'reportsincategory', $reportsincatstr, [get_string('choose')]);

                $mform->addElement(
                    'textarea',
                    'remotequerysql',
                    get_string('remotequerysql', 'block_configurable_reports'),
                    'rows="15" cols="90"'
                );
            }
        }
    }

    /**
     * Server side rules do not work for uploaded files, implement serverside rules here if needed.
     *
     * @param array $data  array of ("fieldname"=>value) of submitted data
     * @param array $files array of uploaded files "element_name"=>tmp_file_path
     * @return array of "element_name"=>"error_description" if there are errors,
     *                     or an empty array if everything is OK (true allowed for backwards compatibility too).
     */
    public function validation($data, $files): array {
        if (get_config('block_configurable_reports', 'sqlsecurity')) {
            return $this->validation_high_security($data, $files);
        }

        return $this->validation_low_security($data, $files);
    }

    /**
     * validation_high_security
     *
     * @param array $data
     * @param array $files
     * @return array
     */
    public function validation_high_security($data, $files): array {
        $errors = parent::validation($data, $files);

        $sql = $data['querysql'];
        $sql = trim($sql);

        // Simple test to avoid evil stuff in the SQL.
        if ($error = report_sql::get_query_security_error($sql)) {
            $errors['querysql'] = get_string($error, 'block_configurable_reports');

        } else if (report_sql::uses_explicit_prefix($sql)) {
            // Make sure prefix is prefix_, not explicit.
            $errors['querysql'] = get_string('noexplicitprefix', 'block_configurable_reports');

        } else {
            // Now try running the SQL, and ensure it runs without errors.

            [$sql, $params] = $this->_customdata['reportclass']->prepare_sql($sql);
            $rs = null;
            try {
                $rs = $this->_customdata['reportclass']->execute_query($sql, $params);
            } catch (dml_read_exception $e) {
                $errors['querysql'] = get_string('queryfailed', 'block_configurable_reports', $e->error);
            }
            if ($rs && !empty($data['singlerow'])) {
                if (iterator_count($rs) === 0) {
                    $errors['querysql'] = get_string('norowsreturned', 'block_configurable_reports');
                }
            }

            if ($rs) {
                $rs->close();
            }
        }

        return $errors;
    }

    /**
     * validation_low_security
     *
     * @param array $data
     * @param array $files
     * @return array
     */
    public function validation_low_security($data, $files) {
        global $CFG;

        $errors = parent::validation($data, $files);

        $sql = $data['querysql'];
        $sql = trim($sql);

        if ($error = report_sql::get_query_security_error($sql)) {
            $errors['querysql'] = get_string($error, 'block_configurable_reports');
        } else {
            // Now try running the SQL, and ensure it runs without errors.
            [$sql, $params] = $this->_customdata['reportclass']->prepare_sql($sql);
            $rs = null;
            try {
                $rs = $this->_customdata['reportclass']->execute_query($sql, $params);
            } catch (dml_exception $e) {
                $errors['querysql'] = get_string('queryfailed', 'block_configurable_reports', $e->error ?? $e->getMessage());
            }
            if ($rs && !empty($data['singlerow'])) {
                if (iterator_count($rs) === 0) {
                    $errors['querysql'] = get_string('norowsreturned', 'block_configurable_reports');
                }
            }

            if ($rs) {
                $rs->close();
            }
        }

        return $errors;
    }

}
