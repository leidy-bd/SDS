<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_configurable_reports\event;

/**
 * Event triggered when a configurable report is updated.
 *
 * @property-read array $other {
 *      - string name: the report name.
 *      - string type: the report type.
 *      - string component: optional, the report component that changed, such as columns or customsql.
 * }
 *
 * @package    block_configurable_reports
 * @copyright  2026 Juan Leyva
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class report_updated extends report_event {

    /**
     * Init method.
     */
    protected function init() {
        parent::init();
        $this->data['crud'] = 'u';
    }

    /**
     * Returns the localised event name.
     *
     * @return string
     */
    public static function get_name() {
        return get_string('eventreportupdated', 'block_configurable_reports');
    }

    /**
     * Returns the description of what happened.
     *
     * @return string
     */
    public function get_description() {
        $component = isset($this->other['component']) ? " ({$this->other['component']})" : '';

        return "The user with id '$this->userid' updated the configurable report with id '$this->objectid'$component.";
    }
}
