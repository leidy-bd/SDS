<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Turkish language pack for block_course_recommender
 *
 * @package    block_course_recommender
 * @category   string
 * @copyright  2025 Sadik Mert
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cachedef_tags'] = 'Etiket listesi önbelleği';
$string['course_recommender:addinstance'] = 'Yeni bir ders öneri bloğu ekle';
$string['course_recommender:myaddinstance'] = 'Yeni bir ders öneri bloğunu Moodle alanıma ekle';
$string['course_recommender:view'] = 'Ders öneri bloğunu görüntüle';

$string['error'] = 'Bir hata oluştu.';

$string['interest_label'] = 'İlgi alan(lar)ınızı seçin';

$string['matchingcourses'] = 'İlgi alan(lar)ınıza uygun dersler';
$string['maxtags'] = 'Etiketlerin maksimum sayısı';
$string['maxtags_desc'] = 'Görüntülenecek maksimum etiket sayısını ayarlayın. '
    . '0 girerseniz tüm etiketler görüntülenir.';

$string['nocourses'] = 'Uygun ders bulunamadı.';
$string['notagsfound'] = 'Dersler için etiket bulunamadı.';
$string['participants'] = '{$a} katılımcı';

$string['pluginname'] = 'Ders önerisi';
$string['popularcourses'] = 'Popüler dersler';
$string['privacy:metadata'] = 'Ders öneri bloğu herhangi bir kişisel veri saklamaz.';

$string['tagcolor'] = 'Etiket Rengi';
$string['tagcolor_desc'] = 'Etiketler için rengi seçin.';
$string['tagsort'] = 'Etiket Sıralama';
$string['tagsort_az'] = 'A-Z';
$string['tagsort_desc'] = 'Etiketler için sıralama düzenini seçin.';
$string['tagsort_popularity'] = 'Popülerlik';
$string['tagsort_za'] = 'Z-A';
