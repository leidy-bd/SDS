<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * English language pack for block_course_recommender
 *
 * @package    block_course_recommender
 * @category   string
 * @copyright  2025 Sadik Mert
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cachedef_tags'] = 'Tag-Liste Cache';
$string['course_recommender:addinstance'] = 'Füge einen neuen Kurs-Empfehlungsblock hinzu';
$string['course_recommender:myaddinstance'] = 'Füge einen neuen Kurs-Empfehlungsblock zu Mein Moodle hinzu';
$string['course_recommender:view'] = 'Kurs-Empfehlungsblock anzeigen';

$string['error'] = 'Es ist ein Fehler aufgetreten.';

$string['interest_label'] = 'Wähle deine Interessen';

$string['matchingcourses'] = 'Kurse, die zu deinen Interessen passen';
$string['maxtags'] = 'Maximale Anzahl von Tags';
$string['maxtags_desc'] = 'Legen Sie die maximale Anzahl von Tags fest, die angezeigt werden sollen. '
    . 'Geben Sie 0 ein, um alle Tags anzuzeigen.';

$string['nocourses'] = 'Keine passenden Kurse gefunden.';
$string['notagsfound'] = 'Keine Tags für Kurse verfügbar.';
$string['participants'] = '{$a} Teilnehmende';

$string['pluginname'] = 'Kurs-Empfehlung';
$string['popularcourses'] = 'Beliebte Kurse';
$string['privacy:metadata'] = 'Der Kurs-Empfehlungsblock speichert keine personenbezogenen Daten.';

$string['searchtags'] = 'Tags suchen';
$string['searchtagshelp'] = 'Die beliebtesten Tags werden zuerst angezeigt. Suche nach weiteren vorhandenen Tags.';
$string['searchtagsplaceholder'] = 'Vorhandene Tags suchen';
$string['tagcolor'] = 'Farbe des Tags';
$string['tagcolor_desc'] = 'Wählen Sie die Farbe für die Tags aus.';
$string['tagsort'] = 'Sortierung der Tags';
$string['tagsort_az'] = 'A-Z';
$string['tagsort_desc'] = 'Wählen Sie die Sortierreihenfolge für die Tags aus.';
$string['tagsort_popularity'] = 'Beliebtheit';
$string['tagsort_za'] = 'Z-A';
