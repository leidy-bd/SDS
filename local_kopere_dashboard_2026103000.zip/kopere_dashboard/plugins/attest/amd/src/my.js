// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * my.js
 *
 * @package   koperedashboard_attest
 * @copyright 2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define([], function () {
    function toggleModal(modal, isOpen) {
        if (!modal) {
            return;
        }

        if (isOpen) {
            modal.removeAttribute("hidden");
            document.body.classList.add("kopere_dashboard-attest-modal-open");
            return;
        }

        modal.setAttribute("hidden", "hidden");
        document.body.classList.remove("kopere_dashboard-attest-modal-open");
    }

    function updateAvailableItems(select, list, items, emptySelect, emptyCourse) {
        if (!select || !list || !items.length) {
            return;
        }

        let selectedCourseId = select.value;
        let visibleCount = 0;

        items.forEach(function (item) {
            let itemCourseId = item.getAttribute("data-kopere_dashboard-attest-course-item");
            let isVisible = selectedCourseId !== "" && itemCourseId === selectedCourseId;

            if (isVisible) {
                item.removeAttribute("hidden");
                visibleCount++;
                return;
            }

            item.setAttribute("hidden", "hidden");
        });

        if (selectedCourseId === "") {
            list.setAttribute("hidden", "hidden");
            if (emptySelect) {
                emptySelect.removeAttribute("hidden");
            }
            if (emptyCourse) {
                emptyCourse.setAttribute("hidden", "hidden");
            }
            return;
        }

        if (emptySelect) {
            emptySelect.setAttribute("hidden", "hidden");
        }

        if (visibleCount > 0) {
            list.removeAttribute("hidden");
            if (emptyCourse) {
                emptyCourse.setAttribute("hidden", "hidden");
            }
            return;
        }

        list.setAttribute("hidden", "hidden");
        if (emptyCourse) {
            emptyCourse.removeAttribute("hidden");
        }
    }

    function resetModalState(select, list, items, emptySelect, emptyCourse) {
        if (select) {
            select.value = "";
        }

        items.forEach(function (item) {
            item.setAttribute("hidden", "hidden");
        });

        if (list) {
            list.setAttribute("hidden", "hidden");
        }

        if (emptySelect) {
            emptySelect.removeAttribute("hidden");
        }

        if (emptyCourse) {
            emptyCourse.setAttribute("hidden", "hidden");
        }
    }

    function init() {
        let modal = document.querySelector("[data-kopere_dashboard-attest-modal]");
        let openButton = document.querySelector("[data-kopere_dashboard-attest-open-modal]");
        let closeButtons = document.querySelectorAll("[data-kopere_dashboard-attest-close]");
        let select = document.querySelector("[data-kopere_dashboard-attest-course-select]");
        let list = document.querySelector("[data-kopere_dashboard-attest-available-list]");
        let items = Array.from(document.querySelectorAll("[data-kopere_dashboard-attest-course-item]"));
        let emptySelect = document.querySelector("[data-kopere_dashboard-attest-empty-select]");
        let emptyCourse = document.querySelector("[data-kopere_dashboard-attest-empty-course]");

        if (!modal || !openButton) {
            return;
        }

        openButton.disabled = false;
        openButton.addEventListener("click", function () {
            resetModalState(select, list, items, emptySelect, emptyCourse);
            toggleModal(modal, true);
        });

        closeButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                toggleModal(modal, false);
            });
        });

        if (select) {
            select.addEventListener("change", function () {
                updateAvailableItems(select, list, items, emptySelect, emptyCourse);
            });
        }

        document.addEventListener("keydown", function (event) {
            if (event.key == "Escape") {
                toggleModal(modal, false);
            }
        });
    }

    return {
        init: init
    };
});
