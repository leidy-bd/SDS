<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Lang file
 *
 * @package   koperedashboard_attest
 * @copyright 2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$string['actions_title'] = 'Tindakan';
$string['all_issues_button'] = 'Lihat semua surat keterangan';
$string['all_issues_desc'] = 'Ditemukan {$a} surat keterangan.';
$string['all_issues_title'] = 'Semua surat keterangan';
$string['already_has_valid'] = 'Dokumen yang valid sudah ada';
$string['attest:manage'] = 'Kelola surat keterangan';
$string['attest:view'] = 'Lihat surat keterangan';
$string['audit_issue_create'] = 'Surat keterangan dibuat.';
$string['audit_tpl_create'] = 'Templat dibuat.';
$string['audit_tpl_delete'] = 'Templat dihapus.';
$string['audit_tpl_update'] = 'Templat diperbarui.';
$string['available_desc'] = 'Hanya surat keterangan dari kursus dengan pendaftaran.';
$string['available_title'] = 'Surat keterangan tersedia';
$string['back_to_templates'] = 'Kembali ke templat';
$string['cap_manage'] = 'Pengelola surat keterangan';
$string['cap_manage_desc'] = 'Dapat membuat dan mengelola templat surat keterangan.';
$string['choose_course'] = 'Pilih kursus';
$string['choose_course_help'] = 'Pilih kursus terlebih dahulu untuk melihat surat keterangan yang tersedia.';
$string['choose_course_placeholder'] = 'Pilih kursus';
$string['close_modal'] = 'Tutup';
$string['course_removed'] = 'Kursus dihapus';
$string['delete_template'] = 'Hapus';
$string['edit_template'] = 'Edit templat';
$string['empty_all_issues'] = 'Tidak ada surat keterangan yang ditemukan dengan filter yang dipilih.';
$string['empty_available'] = 'Tidak ada surat keterangan yang tersedia untuk pendaftaran Anda.';
$string['empty_available_for_course'] = 'Tidak ada surat keterangan yang tersedia untuk kursus yang dipilih.';
$string['empty_available_select_course'] = 'Pilih kursus untuk menampilkan surat keterangan yang tersedia.';
$string['empty_courses'] = 'Saat ini Anda belum terdaftar di kursus apa pun.';
$string['empty_issued'] = 'Anda belum membuat surat keterangan apa pun.';
$string['field_active'] = 'Aktif';
$string['field_allcourses'] = 'Berlaku untuk semua kursus';
$string['field_courses'] = 'Kursus';
$string['field_courses_help'] = 'Pilih kursus tempat templat ini dapat digunakan. Jika "Berlaku untuk semua kursus" dicentang, pengaturan ini akan diabaikan.';
$string['field_html'] = 'Templat HTML';
$string['field_html_help'] = 'Masukkan HTML yang akan digunakan untuk membuat PDF surat keterangan. Anda dapat menggunakan placeholder yang tersedia untuk menyisipkan data dinamis siswa, kursus, tanggal, dan masa berlaku.';
$string['field_name'] = 'Nama';
$string['field_validmonths'] = 'Berlaku selama (bulan)';
$string['filter_all_courses'] = 'Semua kursus';
$string['filter_all_students'] = 'Semua peserta';
$string['filter_apply'] = 'Filter';
$string['filter_clear'] = 'Hapus';
$string['filter_course'] = 'Kursus';
$string['filter_student'] = 'Peserta';
$string['footer_created'] = 'Dibuat pada';
$string['footer_desc'] = 'Dokumen elektronik dengan validasi melalui Kode QR atau tautan di bawah ini.';
$string['footer_hash'] = 'Tanda tangan';
$string['footer_title'] = 'Tanda tangan digital';
$string['footer_validuntil'] = 'Berlaku hingga';
$string['generate_new'] = 'Buat surat keterangan';
$string['generate_new_button'] = 'Buat surat keterangan baru';
$string['home_kpi_subtitle'] = 'Dokumen diterbitkan dan valid';
$string['home_kpi_title'] = 'Surat keterangan valid';
$string['issued_desc'] = 'Lihat surat keterangan yang sudah dibuat dan apakah masih valid.';
$string['issued_title'] = 'Surat keterangan dibuat';
$string['manage_title'] = 'Templat surat keterangan';
$string['menu_desc'] = 'Buat surat keterangan PDF berdasarkan templat HTML.';
$string['new_template'] = 'Templat baru';
$string['open_attestation'] = 'Buka surat keterangan';
$string['open_valid'] = 'Buka surat keterangan valid';
$string['placeholders_title'] = 'Placeholder tersedia';
$string['pluginname'] = 'Surat keterangan';
$string['recreate_valid'] = 'Buat ulang surat keterangan valid';
$string['status_expired'] = 'Kedaluwarsa';
$string['status_notgenerated'] = 'Belum dibuat';
$string['status_title'] = 'Status';
$string['status_valid'] = 'Valid';
$string['status_valid_expiring'] = 'Valid dan hampir kedaluwarsa';
$string['student_removed'] = 'Peserta dihapus (#{$a})';
$string['student_title'] = 'Surat keterangan saya';
$string['studentcard'] = 'Kartu pelajar';
$string['studentcard_back_placeholder_description'] = 'Teks penjelasan terjemahan yang ditampilkan pada sisi validasi.';
$string['studentcard_back_placeholder_fullname'] = 'Nama lengkap peserta didik.';
$string['studentcard_back_placeholder_hashlabel'] = 'Label terjemahan yang ditampilkan sebelum kode validasi.';
$string['studentcard_back_placeholder_qrcode'] = 'Kode QR validasi sebagai URI data PNG Base64 tertanam.';
$string['studentcard_back_placeholder_sitefullname'] = 'Nama lengkap situs Moodle yang telah diformat.';
$string['studentcard_back_placeholder_title'] = 'Judul terjemahan untuk sisi validasi.';
$string['studentcard_back_placeholder_userid'] = 'ID numerik pengguna Moodle.';
$string['studentcard_back_placeholder_validationcode'] = 'Kode validasi publik yang dibuat untuk kartu pelajar.';
$string['studentcard_back_placeholder_verifyurl'] = 'URL publik yang digunakan untuk memvalidasi kartu pelajar.';
$string['studentcard_desc'] = '';
$string['studentcard_front_placeholder_coursefullname'] = 'Nama lengkap terformat dari kursus terlihat pertama tempat peserta didik terdaftar.';
$string['studentcard_front_placeholder_courselabel'] = 'Label kursus yang diterjemahkan.';
$string['studentcard_front_placeholder_cpf'] = 'CPF yang diperoleh dari kolom profil khusus, dengan nomor identifikasi sebagai alternatif.';
$string['studentcard_front_placeholder_cpflabel'] = 'Label kolom CPF.';
$string['studentcard_front_placeholder_email'] = 'Alamat email peserta didik.';
$string['studentcard_front_placeholder_fullname'] = 'Nama lengkap peserta didik.';
$string['studentcard_front_placeholder_photo'] = 'Foto profil sebagai URI data gambar Base64 tertanam.';
$string['studentcard_front_placeholder_title'] = 'Judul kartu pelajar yang diterjemahkan.';
$string['studentcard_front_placeholder_userid'] = 'ID numerik pengguna Moodle.';
$string['studentcard_settings_back'] = 'Templat sisi belakang';
$string['studentcard_settings_back_template'] = 'Mustache sisi belakang';
$string['studentcard_settings_back_variables'] = 'Variabel yang tersedia pada sisi belakang';
$string['studentcard_settings_back_variables_desc'] = 'Variabel Mustache ini diganti saat membuat sisi validasi PDF.';
$string['studentcard_settings_description'] = 'Edit dua templat Mustache/HTML yang digunakan untuk membuat PDF kartu pelajar. Sisi depan memuat identitas peserta didik dan kursus; sisi belakang memuat kode, tautan publik, dan kode QR validasi.';
$string['studentcard_settings_front'] = 'Templat sisi depan';
$string['studentcard_settings_front_template'] = 'Mustache sisi depan';
$string['studentcard_settings_front_variables'] = 'Variabel yang tersedia pada sisi depan';
$string['studentcard_settings_front_variables_desc'] = 'Variabel Mustache ini diganti saat membuat sisi identifikasi PDF.';
$string['studentcard_settings_menu'] = 'Templat kartu pelajar';
$string['studentcard_settings_title'] = 'Templat kartu pelajar';
$string['studentcardgenerate'] = 'Buat PDF';
$string['studentcardnophoto'] = '<h5>Anda tidak memiliki foto profil.</h5>Edit profil Anda dan tambahkan foto untuk membuat kartu pelajar.';
$string['studentcardnovisiblecourses'] = 'Kartu pelajar hanya tersedia untuk pengguna yang terdaftar di kursus yang terlihat.';
$string['studentcardsignaturedesc'] = 'Halaman ini berisi kode validasi dan tautan validator publik untuk PDF kartu pelajar.';
$string['studentcardsignaturetitle'] = 'Tanda tangan digital dan validator';
$string['template_removed'] = 'Templat dihapus';
$string['title_view'] = 'Surat keterangan';
$string['verify_title'] = 'Verifikasi surat keterangan';
