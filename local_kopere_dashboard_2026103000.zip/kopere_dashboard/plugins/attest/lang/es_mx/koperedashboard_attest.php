<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Lang file
 *
 * @package   koperedashboard_attest
 * @copyright 2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$string['actions_title'] = 'Acciones';
$string['all_issues_button'] = 'Ver todas las constancias';
$string['all_issues_desc'] = 'Se encontraron {$a} constancia(s).';
$string['all_issues_title'] = 'Todas las constancias';
$string['already_has_valid'] = 'Ya existe una constancia válida';
$string['attest:manage'] = 'Administrar constancias';
$string['attest:view'] = 'Ver constancias';
$string['audit_issue_create'] = 'Constancia generada.';
$string['audit_tpl_create'] = 'Plantilla creada.';
$string['audit_tpl_delete'] = 'Plantilla eliminada.';
$string['audit_tpl_update'] = 'Plantilla actualizada.';
$string['available_desc'] = 'Solo constancias de cursos con inscripción.';
$string['available_title'] = 'Constancias disponibles';
$string['back_to_templates'] = 'Volver a las plantillas';
$string['cap_manage'] = 'Administrador de constancias';
$string['cap_manage_desc'] = 'Puede crear y administrar plantillas de constancias.';
$string['choose_course'] = 'Elige un curso';
$string['choose_course_help'] = 'Primero selecciona el curso para ver las constancias disponibles.';
$string['choose_course_placeholder'] = 'Selecciona un curso';
$string['close_modal'] = 'Cerrar';
$string['course_removed'] = 'Curso eliminado';
$string['delete_template'] = 'Eliminar';
$string['edit_template'] = 'Editar plantilla';
$string['empty_all_issues'] = 'No se encontraron constancias con los filtros seleccionados.';
$string['empty_available'] = 'No hay constancias disponibles para tus inscripciones.';
$string['empty_available_for_course'] = 'No hay constancias disponibles para el curso seleccionado.';
$string['empty_available_select_course'] = 'Selecciona un curso para listar las constancias disponibles.';
$string['empty_courses'] = 'Actualmente no estás inscrito en ningún curso.';
$string['empty_issued'] = 'Aún no has generado ninguna constancia.';
$string['field_active'] = 'Activo';
$string['field_allcourses'] = 'Válido para todos los cursos';
$string['field_courses'] = 'Cursos';
$string['field_courses_help'] = 'Selecciona los cursos en los que se puede usar esta plantilla. Si "Válido para todos los cursos" está marcado, esta configuración se ignorará.';
$string['field_html'] = 'Plantilla HTML';
$string['field_html_help'] = 'Ingresa el HTML que se usará para generar el PDF de la constancia. Puedes usar los marcadores disponibles para insertar datos dinámicos del estudiante, curso, fecha y vigencia.';
$string['field_name'] = 'Nombre';
$string['field_validmonths'] = 'Válido por (meses)';
$string['filter_all_courses'] = 'Todos los cursos';
$string['filter_all_students'] = 'Todos los estudiantes';
$string['filter_apply'] = 'Filtrar';
$string['filter_clear'] = 'Limpiar';
$string['filter_course'] = 'Curso';
$string['filter_student'] = 'Estudiante';
$string['footer_created'] = 'Creado el';
$string['footer_desc'] = 'Documento electrónico con validación mediante código QR o el enlace de abajo.';
$string['footer_hash'] = 'Firma';
$string['footer_title'] = 'Firma digital';
$string['footer_validuntil'] = 'Válido hasta';
$string['generate_new'] = 'Generar constancia';
$string['generate_new_button'] = 'Generar nueva constancia';
$string['home_kpi_subtitle'] = 'Documentos emitidos y vigentes';
$string['home_kpi_title'] = 'Constancias vigentes';
$string['issued_desc'] = 'Consulta las constancias ya generadas y si todavía están vigentes.';
$string['issued_title'] = 'Constancias generadas';
$string['manage_title'] = 'Plantillas de constancias';
$string['menu_desc'] = 'Genera constancias en PDF con base en plantillas HTML.';
$string['new_template'] = 'Nueva plantilla';
$string['open_attestation'] = 'Abrir constancia';
$string['open_valid'] = 'Abrir constancia vigente';
$string['placeholders_title'] = 'Marcadores disponibles';
$string['pluginname'] = 'Constancias';
$string['recreate_valid'] = 'Recrear constancia vigente';
$string['status_expired'] = 'Vencida';
$string['status_notgenerated'] = 'Aún no generada';
$string['status_title'] = 'Estado';
$string['status_valid'] = 'Vigente';
$string['status_valid_expiring'] = 'Vigente y próxima a vencer';
$string['student_removed'] = 'Estudiante eliminado (#{$a})';
$string['student_title'] = 'Mis constancias';
$string['studentcard'] = 'Credencial de estudiante';
$string['studentcard_back_placeholder_description'] = 'Texto explicativo traducido que se muestra en el lado de validación.';
$string['studentcard_back_placeholder_fullname'] = 'Nombre completo del estudiante.';
$string['studentcard_back_placeholder_hashlabel'] = 'Etiqueta traducida que se muestra antes del código de validación.';
$string['studentcard_back_placeholder_qrcode'] = 'Código QR de validación como URI de datos PNG Base64 incrustada.';
$string['studentcard_back_placeholder_sitefullname'] = 'Nombre completo con formato del sitio Moodle.';
$string['studentcard_back_placeholder_title'] = 'Título traducido del lado de validación.';
$string['studentcard_back_placeholder_userid'] = 'ID numérico del usuario en Moodle.';
$string['studentcard_back_placeholder_validationcode'] = 'Código público de validación generado para la credencial de estudiante.';
$string['studentcard_back_placeholder_verifyurl'] = 'URL pública utilizada para validar la credencial de estudiante.';
$string['studentcard_desc'] = '';
$string['studentcard_front_placeholder_coursefullname'] = 'Nombre completo con formato del primer curso visible en el que está inscrito el estudiante.';
$string['studentcard_front_placeholder_courselabel'] = 'Etiqueta traducida del curso.';
$string['studentcard_front_placeholder_cpf'] = 'CPF obtenido del campo personalizado del perfil, usando el número de identificación como alternativa.';
$string['studentcard_front_placeholder_cpflabel'] = 'Etiqueta del campo CPF.';
$string['studentcard_front_placeholder_email'] = 'Correo electrónico del estudiante.';
$string['studentcard_front_placeholder_fullname'] = 'Nombre completo del estudiante.';
$string['studentcard_front_placeholder_photo'] = 'Foto de perfil como URI de datos de imagen Base64 incrustada.';
$string['studentcard_front_placeholder_title'] = 'Título traducido de la credencial de estudiante.';
$string['studentcard_front_placeholder_userid'] = 'ID numérico del usuario en Moodle.';
$string['studentcard_settings_back'] = 'Plantilla del reverso';
$string['studentcard_settings_back_template'] = 'Mustache del reverso';
$string['studentcard_settings_back_variables'] = 'Variables disponibles en el reverso';
$string['studentcard_settings_back_variables_desc'] = 'Estas variables Mustache se reemplazan al generar el lado de validación del PDF.';
$string['studentcard_settings_description'] = 'Edite las dos plantillas Mustache/HTML utilizadas para generar el PDF de la credencial de estudiante. El frente contiene la identidad del estudiante y el curso; el reverso contiene el código, el enlace público y el código QR de validación.';
$string['studentcard_settings_front'] = 'Plantilla del frente';
$string['studentcard_settings_front_template'] = 'Mustache del frente';
$string['studentcard_settings_front_variables'] = 'Variables disponibles en el frente';
$string['studentcard_settings_front_variables_desc'] = 'Estas variables Mustache se reemplazan al generar el lado de identificación del PDF.';
$string['studentcard_settings_menu'] = 'Plantilla de la credencial de estudiante';
$string['studentcard_settings_title'] = 'Plantilla de la credencial de estudiante';
$string['studentcardgenerate'] = 'Generar PDF';
$string['studentcardnophoto'] = '<h5>No tienes una foto de perfil.</h5>Edita tu perfil y agrega una foto para generar tu credencial de estudiante.';
$string['studentcardnovisiblecourses'] = 'La credencial de estudiante solo está disponible para usuarios inscritos en cursos visibles.';
$string['studentcardsignaturedesc'] = 'Esta página contiene el código de validación y el enlace público de validación del PDF de la credencial de estudiante.';
$string['studentcardsignaturetitle'] = 'Firma digital y validador';
$string['template_removed'] = 'Plantilla eliminada';
$string['title_view'] = 'Constancias';
$string['verify_title'] = 'Verificación de constancia';
