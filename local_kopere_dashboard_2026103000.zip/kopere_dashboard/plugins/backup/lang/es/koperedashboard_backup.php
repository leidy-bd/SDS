<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Lang file
 *
 * @package   koperedashboard_backup
 * @copyright 2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$string['action_delete'] = 'Eliminar';
$string['action_download'] = 'Descargar';
$string['action_generate_database'] = 'Exportar base de datos';
$string['action_generate_moodledata'] = 'Generar copia de seguridad de moodledata';
$string['cannotopenexportfile'] = 'No se pudo abrir el archivo de exportación: {$a}';
$string['cap_generate'] = 'Generar copias de seguridad';
$string['cap_generate_desc'] = 'Permite a los usuarios generar archivos de copia de seguridad de moodledata y copias de seguridad de la base de datos.';
$string['cap_view'] = 'Ver centro de copias de seguridad';
$string['cap_view_desc'] = 'Permite a los usuarios acceder al centro de copias de seguridad y descargar los archivos generados.';
$string['col_actions'] = 'Acciones';
$string['col_created'] = 'Creado el';
$string['col_file'] = 'Archivo';
$string['col_size'] = 'Tamaño';
$string['col_type'] = 'Tipo';
$string['current_source_label'] = 'Base de datos actual:';
$string['database_desc'] = 'Exporta la estructura y los datos de la base de datos en PHP, lo que permite elegir el formato de salida y, opcionalmente, separar los registros en su propio archivo.';
$string['database_success'] = 'Exportación de la base de datos generada correctamente: {$a}';
$string['database_title'] = 'Exportación de la base de datos';
$string['delete_cancel'] = 'Cancelar';
$string['delete_confirm_button'] = 'Sí, eliminar archivo';
$string['delete_confirm_message'] = '¿Seguro que desea eliminar este archivo de copia de seguridad generado? Esta acción no se puede deshacer.';
$string['delete_confirm_title'] = 'Eliminar archivo de copia de seguridad';
$string['delete_success'] = 'Archivo de copia de seguridad eliminado correctamente: {$a}';
$string['deletefailed'] = 'No se pudo eliminar el archivo de copia de seguridad: {$a}';
$string['emptyfiles'] = 'Aún no se han generado archivos de copia de seguridad.';
$string['exportscope_full'] = 'Base de datos completa';
$string['exportscope_logs'] = 'Solo registros';
$string['exportscope_main'] = 'Base de datos sin registros';
$string['filenotfound'] = 'Archivo de copia de seguridad no encontrado: {$a}';
$string['format_mysql'] = 'MySQL / MariaDB';
$string['format_pgsql'] = 'PostgreSQL';
$string['friendly_installation_alternative_not_desc'] = 'Instala y configura <a href="https://moodle.org/plugins/local_alternative_file_system" target="_blank">Alternative File System</a> para optimizar el tiempo de migración, mantener los archivos de Moodle en almacenamiento remoto, reducir la presión sobre el disco local, facilitar entornos en clúster, mejorar la resiliencia y usar entrega por CDN cuando aplique. Sin él, esta exportación incluirá los archivos locales de moodledata en el ZIP generado.';
$string['friendly_installation_alternative_not_title'] = 'Alternative File System no instalado o no configurado';
$string['friendly_installation_alternative_ok_desc'] = 'Verifica en el <a href="{$a}" target="_blank">sistema de archivos alternativo</a> que todos los archivos estén en el almacenamiento remoto antes de realizar la restauración.';
$string['friendly_installation_alternative_ok_title'] = 'Alternative File System instalado';
$string['friendly_installation_desc'] = 'Exporta la base de datos en un formato compatible con el <a href="https://github.com/EduardoKrausME/moodle_friendly_installation" target="_blank">Instalador del software Moodle™</a> y MoodleData.';
$string['friendly_installation_generate'] = 'Exportar';
$string['friendly_installation_success'] = '¡Exportación generada correctamente!';
$string['friendly_installation_title'] = 'Exportación para el Instalador del software Moodle™';
$string['gzipnotavailable'] = 'La extensión PHP zlib/gzip no está disponible en este servidor.';
$string['history_title'] = 'Archivos generados';
$string['home_kpi_empty_subtitle'] = 'Ninguna copia de seguridad generada';
$string['home_kpi_empty_value'] = '-';
$string['home_kpi_subtitle'] = 'Archivo más reciente: {$a}';
$string['home_kpi_title'] = 'Última copia de seguridad';
$string['invalidaction'] = 'La acción solicitada no es válida.';
$string['invalidfilename'] = 'El nombre de archivo especificado no es válido.';
$string['invalidoutputformat'] = 'El formato de salida especificado no es válido: {$a}';
$string['menu_desc'] = 'Generación manual de copias de seguridad de moodledata y exportación de la base de datos';
$string['menu_title'] = 'Copias de seguridad';
$string['moodledata_desc'] = 'Genera un paquete completo de la carpeta moodledata, excluyendo solo la carpeta donde se almacenan las propias copias de seguridad.';
$string['moodledata_success'] = 'Copia de seguridad de moodledata generada correctamente: {$a}';
$string['moodledata_title'] = 'Copia de seguridad de moodledata';
$string['notablesfound'] = 'No se encontraron tablas para exportar.';
$string['outputformat_desc'] = 'Puede exportar al formato de la base de datos actual o convertir la salida entre MySQL/MariaDB y PostgreSQL.';
$string['outputformat_label'] = 'Formato de salida';
$string['page_title'] = 'Centro de copias de seguridad';
$string['pluginname'] = 'Copias de seguridad';
$string['processfailed'] = 'Error al ejecutar el proceso de copia de seguridad: {$a}';
$string['processstartfailed'] = 'No se pudo iniciar el proceso de copia de seguridad en el servidor.';
$string['separatelogs_desc'] = 'Cuando está activado, el sistema genera un paquete ZIP con un archivo para la base de datos principal y otro archivo solo para las tablas de registros.';
$string['separatelogs_label'] = '¿Desea exportar los registros por separado?';
$string['type_database'] = 'Base de datos';
$string['type_friendly_installation'] = 'Instalador del software Moodle™';
$string['type_moodledata'] = 'Moodledata';
$string['unknownprocesserror'] = 'El proceso devolvió un error, pero no proporcionó detalles.';
$string['unsupporteddbtype'] = 'Tipo de base de datos no compatible con este plugin de copias de seguridad: {$a}';
$string['zipcreatefailed'] = 'No se pudo crear el archivo ZIP.';
