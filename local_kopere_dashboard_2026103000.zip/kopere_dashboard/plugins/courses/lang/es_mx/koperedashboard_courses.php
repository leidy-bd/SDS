<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Lang file
 *
 * @package   koperedashboard_courses
 * @copyright 2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$string['action_edit_course'] = 'Editar configuración';
$string['action_gradebook'] = 'Libro de calificaciones';
$string['action_logs'] = 'Registros';
$string['action_open'] = 'Abrir';
$string['action_open_course'] = 'Abrir curso';
$string['action_participants'] = 'Participantes';
$string['cap_manage'] = 'Administrar hub de cursos';
$string['cap_manage_desc'] = 'Permite acceder a acciones de administración en el hub de cursos.';
$string['col_accepted'] = 'Aceptado';
$string['col_actions'] = 'Acciones';
$string['col_active'] = 'Activo';
$string['col_amount'] = 'Monto';
$string['col_category'] = 'Categoría';
$string['col_contract'] = 'Contrato';
$string['col_created'] = 'Creado';
$string['col_email'] = 'Correo electrónico';
$string['col_fullname'] = 'Nombre completo';
$string['col_id'] = 'ID';
$string['col_installments'] = 'Parcialidades';
$string['col_lastaccess'] = 'Último acceso';
$string['col_modified'] = 'Modificado';
$string['col_name'] = 'Nombre';
$string['col_nextdue'] = 'Próximo vencimiento';
$string['col_overdue'] = 'Vencido';
$string['col_pending'] = 'Pendiente';
$string['col_plan'] = 'Plan';
$string['col_plan_users'] = 'Usuarios activos';
$string['col_shortname'] = 'Nombre corto';
$string['col_status'] = 'Estado';
$string['col_subject'] = 'Asunto';
$string['col_user'] = 'Usuario';
$string['col_visible'] = 'Visible';
$string['courses:manage'] = 'Administrar cursos';
$string['empty_query_title'] = 'Cursos modificados recientemente';
$string['label_enddate'] = 'Fin';
$string['label_idnumber'] = 'Número de identificación';
$string['label_modified'] = 'Modificado';
$string['label_shortname'] = 'Nombre corto';
$string['label_startdate'] = 'Inicio';
$string['menu_desc'] = 'Búsqueda rápida y accesos directos de cursos';
$string['menu_title'] = 'Cursos';
$string['metric_cohorts'] = 'Cohortes';
$string['metric_contracts'] = 'Contratos';
$string['metric_enrolled'] = 'Usuarios inscritos';
$string['metric_plans'] = 'Planes';
$string['metric_requests_open'] = 'Solicitudes abiertas';
$string['no_participants_cap'] = 'No tienes permiso para ver los participantes de este curso.';
$string['no_results'] = 'No se encontraron cursos.';
$string['page_title'] = 'Búsqueda de cursos';
$string['pluginname'] = 'Cursos';
$string['quick_links'] = 'Enlaces rápidos';
$string['quick_open_contracts'] = 'Contratos';
$string['quick_open_plans'] = 'Pagos recurrentes';
$string['quick_open_requests'] = 'Solicitudes';
$string['search_back'] = 'Volver a la búsqueda';
$string['search_help'] = 'Escribe al menos 2 caracteres para ver sugerencias. Presiona Enter para buscar.';
$string['search_label'] = 'Buscar';
$string['search_placeholder'] = 'Nombre del curso, nombre corto o número de identificación';
$string['section_cohorts'] = 'Cohortes';
$string['section_contracts'] = 'Contratos';
$string['section_overview'] = 'Vista general';
$string['section_participants'] = 'Participantes (muestra)';
$string['section_plans'] = 'Planes';
$string['section_requests'] = 'Solicitudes';
$string['view_title'] = 'Curso: {$a}';
$string['visible_no'] = 'Oculto';
$string['visible_yes'] = 'Visible';
