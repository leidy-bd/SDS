<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Lang file
 *
 * @package   koperedashboard_contracts
 * @copyright 2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$string['accept_title'] = 'Aceptación del contrato';
$string['accepted'] = 'Aceptado';
$string['btn_accept'] = 'Estoy de acuerdo y acepto';
$string['btn_save'] = 'Guardar';
$string['cap_manage'] = 'Gestor de contratos';
$string['cap_manage_desc'] = 'Puede crear, editar y eliminar contratos y vincularlos a cursos.';
$string['contracts:accept'] = 'Aceptar contratos';
$string['contracts:manage'] = 'Gestionar contratos';
$string['deletecontract'] = 'Eliminar';
$string['editcontract'] = 'Editar contrato';
$string['field_active'] = 'Activo';
$string['field_content'] = 'Contenido del contrato';
$string['field_course'] = 'Curso';
$string['field_courses'] = 'Cursos';
$string['field_name'] = 'Nombre';
$string['field_readseconds'] = 'Tiempo de lectura (s)';
$string['field_summary'] = 'Resumen';
$string['field_timeaccepted'] = 'Firmado el';
$string['field_user'] = 'Estudiante';
$string['home_kpi_subtitle'] = 'Plantillas disponibles para aceptación';
$string['home_kpi_title'] = 'Contratos activos';
$string['manage_title'] = 'Gestión de contratos';
$string['menu_desc'] = 'Cree contratos, vincúlelos a cursos y recopile la aceptación de los estudiantes.';
$string['menu_title'] = 'Contratos';
$string['my_title'] = 'Mis contratos';
$string['newcontract'] = 'Nuevo contrato';
$string['nocontracts'] = 'No se encontraron contratos.';
$string['opencontract'] = 'Abrir contrato';
$string['pluginname'] = 'Contratos';
$string['profile_section_title'] = 'Contratos aceptados';
$string['signatures_title'] = 'Firmas del contrato';
$string['viewsignatures'] = 'Ver firmas';
