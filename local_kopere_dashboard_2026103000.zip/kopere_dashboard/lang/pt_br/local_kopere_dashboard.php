<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Lang file
 *
 * @package   local_kopere_dashboard
 * @copyright 2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$string['about_description_text'] = 'O Kopere Dashboard centraliza rotinas acadêmicas, financeiras, operacionais e administrativas em uma única interface dentro do Moodle.';
$string['about_description_title'] = 'Sobre o plugin';
$string['about_github_label'] = 'GitHub';
$string['about_support_text'] = 'Para documentação, código-fonte ou evolução do projeto, use os links abaixo.';
$string['about_support_title'] = 'Links úteis';
$string['about_website_label'] = 'Site do desenvolvedor';
$string['active'] = 'Ativo';
$string['audit'] = 'Log de auditoria';
$string['audit_action'] = 'Ação';
$string['audit_component'] = 'Componente';
$string['audit_description'] = 'Descrição';
$string['audit_filter'] = 'Filtrar';
$string['audit_latest'] = 'Últimas atividades (Auditoria)';
$string['audit_search'] = 'Pesquisar';
$string['audit_time'] = 'Hora';
$string['audit_user'] = 'Usuário';
$string['bi_course_details'] = 'Atividade recente dos participantes';
$string['bi_detail_name'] = 'Nome';
$string['bi_global_reports_note'] = 'Estes relatórios do BI abrangem a plataforma e não são filtrados para este usuário.';
$string['bi_metric_courses'] = 'Cursos acessados';
$string['bi_metric_lastaccess'] = 'Último acesso registrado';
$string['bi_metric_participants'] = 'Usuários com acesso registrado';
$string['bi_metric_time'] = 'Tempo registrado';
$string['bi_metric_visits'] = 'Visitas registradas';
$string['bi_never_accessed'] = 'Nenhum acesso registrado';
$string['bi_reports_title'] = 'Relatórios relacionados do Kopere BI';
$string['bi_section_title'] = 'Kopere BI: indicadores de aprendizagem';
$string['bi_tracking_note'] = 'Os indicadores consideram os acessos registrados pelo Kopere BI, não toda a atividade do Moodle.';
$string['bi_user_details'] = 'Cursos acessados recentemente';
$string['cat_academic'] = 'Acadêmico';
$string['cat_financial'] = 'Financeiro';
$string['cat_pedagogic'] = 'Pedagógico';
$string['cat_settings'] = 'Configurações';
$string['cat_tools'] = 'Ferramentas';
$string['chart_contracts_title'] = 'Status dos contratos';
$string['chart_enrollments_title'] = 'Visão geral das matrículas';
$string['contracts_expired'] = 'Expirados';
$string['contracts_pending'] = 'Pendentes';
$string['contracts_signed'] = 'Assinados';
$string['dashboard'] = 'Dashboard';
$string['datatables_buttons_copyKeys'] = 'Pressione <i>ctrl</i> ou <i>\\u2318</i> + <i>C</i> para copiar os dados da tabela<br>para a área de transferência do sistema.<br><br>Para cancelar, clique nesta mensagem ou pressione Esc.';
$string['datatables_buttons_copySuccess1'] = 'Uma linha copiada para a área de transferência';
$string['datatables_buttons_copySuccess_'] = '%d linhas copiadas para a área de transferência';
$string['datatables_buttons_copyTitle'] = 'Copiar para a área de transferência';
$string['datatables_buttons_copy_text'] = 'Copiar dados';
$string['datatables_buttons_csv_text'] = 'Baixar CSV';
$string['datatables_buttons_pageLength_'] = 'Mostrar %d itens';
$string['datatables_buttons_pageLength_1'] = 'Mostrar todos';
$string['datatables_buttons_print_text'] = 'Imprimir';
$string['datatables_buttons_select_rows1'] = '1 linha selecionada';
$string['datatables_buttons_select_rows_'] = '%d linhas selecionadas';
$string['datatables_oAria_sSortAscending'] = ': Ordenar colunas em ordem crescente';
$string['datatables_oAria_sSortDescending'] = ': Ordenar colunas em ordem decrescente';
$string['datatables_oPaginate_sFirst'] = 'Primeiro';
$string['datatables_oPaginate_sLast'] = 'Último';
$string['datatables_oPaginate_sNext'] = 'Próximo';
$string['datatables_oPaginate_sPrevious'] = 'Anterior';
$string['datatables_sEmptyTable'] = 'Nenhum registro encontrado';
$string['datatables_sErrorMessage'] = '<strong>Erro ao carregar os dados</strong><div>Tentando novamente em {$a} segundos</div>';
$string['datatables_sInfo'] = '_START_ a _END_ de _TOTAL_';
$string['datatables_sInfoEmpty'] = '0 registros';
$string['datatables_sInfoFiltered'] = '(Filtrado de _MAX_ registros)';
$string['datatables_sInfoThousands'] = '.';
$string['datatables_sLengthMenu'] = '_MENU_ por página';
$string['datatables_sLoadingRecords'] = 'Carregando ...';
$string['datatables_sProcessing'] = 'Processando ...';
$string['datatables_sSearch'] = 'Pesquisar';
$string['datatables_sZeroRecords'] = 'Nenhum registro encontrado';
$string['deleted_successfully'] = 'Excluído com sucesso';
$string['globalsettings'] = 'Configurações globais';
$string['help_title'] = 'Ajuda';
$string['inactive'] = 'Inativo';
$string['invisible'] = 'Oculto';
$string['js_completed'] = 'Concluído';
$string['js_processing'] = 'Processando...';
$string['kopere_dashboard:managepermissions'] = 'Gerenciar permissões do Kopere Dashboard';
$string['kopere_dashboard:view'] = 'Visualizar o Kopere Dashboard';
$string['kopere_dashboard:viewaudit'] = 'Visualizar o log de auditoria do Kopere Dashboard';
$string['m1'] = '1 mês';
$string['m2'] = '2 meses';
$string['m3'] = '3 meses';
$string['m4'] = '4 meses';
$string['m5'] = '5 meses';
$string['m6'] = '6 meses';
$string['managekopere_dashboardplugins'] = 'Gerenciar plugins do Kopere Dashboard';
$string['managekopere_dashboardplugins_desc'] = 'Ative, desative e organize a ordem dos plugins. A ordem definida aqui também será usada para montar os menus do Kopere Dashboard.';
$string['menu_about'] = 'Sobre';
$string['menu_about_desc'] = 'Informações de versão, links úteis e detalhes do Kopere Dashboard.';
$string['menu_close'] = 'Fechar menu';
$string['menu_navigation'] = 'Menu de navegação';
$string['messageprovider:local_kopere_dashboard_messages'] = 'Enviar notificações';
$string['movedown'] = 'Mover para baixo';
$string['moveup'] = 'Mover para cima';
$string['notification_manager'] = 'Preferências de notificações';
$string['order'] = 'Ordem';
$string['permissions'] = 'Permissões';
$string['permissions_add'] = '← Adicionar';
$string['permissions_current_users'] = 'Usuários com acesso';
$string['permissions_desc'] = 'Esta tela reúne as permissões do Kopere Dashboard e de seus plugins. Cada bloco representa uma permissão disponível no sistema e mostra o que os usuários podem fazer. Ao gerenciar permissões, você pode definir quem terá acesso a cada ação, organizando perfis conforme a responsabilidade de cada equipe, como secretaria, financeiro, coordenação ou suporte. Use esta área para revisar cuidadosamente os acessos, evitando conceder permissões além do necessário.';
$string['permissions_manage'] = 'Gerenciar';
$string['permissions_potential_users'] = 'Usuários sem acesso';
$string['permissions_remove'] = 'Remover →';
$string['permissions_users_desc'] = 'Use os seletores para adicionar ou remover usuários desta permissão (atribuição de papel no contexto do sistema).';
$string['php_security_notice_description'] = 'O PHP {$a->version} está abaixo da versão oficial corrigida {$a->fixedversion}. Duas falhas críticas podem permitir execução remota de código sem autenticação. Atualize o PHP e reinicie os processos web do PHP. Algumas distribuições Linux aplicam correções sem alterar o número da versão; confira o pacote instalado.';
$string['php_security_notice_details'] = 'Ler o comunicado oficial do PHP';
$string['php_security_notice_dismiss'] = 'Dispensar este aviso para a versão atual do PHP';
$string['php_security_notice_label'] = 'Alerta crítico de segurança - 21 de outubro de 2026';
$string['php_security_notice_title'] = 'Vulnerabilidades críticas de segurança no PHP';
$string['php_security_notice_unsupported_description'] = 'O PHP {$a} é anterior às versões mantidas que receberam estas correções. Atualize para uma versão de PHP suportada e corrigida e reinicie os processos web. Verifique se a sua distribuição Linux já aplicou as correções por backport.';
$string['plugin_external'] = 'Plugin externo';
$string['pluginname'] = 'Kopere Dashboard';
$string['pluginstatus_activate'] = 'Ativar';
$string['pluginstatus_active'] = 'Ativo';
$string['pluginstatus_deactivate'] = 'Desativar';
$string['pluginstatus_inactive'] = 'Inativo';
$string['reports'] = 'Relatórios';
$string['reports_export'] = 'Exportar';
$string['saved_successfully'] = 'Salvo com sucesso';
$string['showmenu'] = 'Mostrar menu';
$string['showmenu_desc'] = 'Quando ativado, o Kopere Dashboard adiciona seu link na navegação e no menu personalizado do Moodle. Quando desativado, a função de navegação é ignorada.';
$string['status'] = 'Status';
$string['student_courses_empty'] = 'Você ainda não tem cursos ativos para acompanhar aqui.';
$string['student_courses_title'] = 'Meus cursos';
$string['student_courses_title_desc'] = 'Abra a lista completa dos seus cursos.';
$string['student_kpi_completed_courses'] = 'Cursos concluídos';
$string['student_kpi_completed_courses_sub'] = 'Já concluídos por você';
$string['student_kpi_enrolled_courses'] = 'Cursos matriculados';
$string['student_kpi_enrolled_courses_sub'] = 'Total de cursos ativos no momento';
$string['student_kpi_in_progress_courses'] = 'Em andamento';
$string['student_kpi_in_progress_courses_sub'] = 'Cursos com atividade recente';
$string['student_kpi_tracked_courses'] = 'Com progresso';
$string['student_kpi_tracked_courses_sub'] = 'Cursos acompanhados por conclusão';
$string['student_lastaccess'] = 'Último acesso';
$string['student_never_accessed'] = 'Ainda não acessado';
$string['student_progress'] = 'Progresso';
$string['student_progress_not_available'] = 'Não disponível';
$string['student_quicklink_calendar'] = 'Calendário';
$string['student_quicklink_calendar_desc'] = 'Veja prazos, eventos e atividades importantes.';
$string['student_quicklink_profile'] = 'Meu perfil';
$string['student_quicklink_profile_desc'] = 'Revise suas informações pessoais e preferências.';
$string['student_quicklinks_title'] = 'Atalhos rápidos';
$string['student_status_completed'] = 'Concluído';
$string['student_status_inprogress'] = 'Em andamento';
$string['student_status_notstarted'] = 'Não iniciado';
$string['student_welcome_desc'] = 'Acompanhe seus cursos, veja seu progresso e retome rapidamente o que precisa estudar.';
$string['student_welcome_title'] = 'Seu painel do estudante';
$string['subplugintype_koperedashboard'] = 'Plugin';
$string['subplugintype_koperedashboard_plural'] = 'Plugins';
$string['visible'] = 'Visível';
$string['webpages_allpages'] = 'Todas as páginas';
$string['welcome_desc'] = 'O hub completo para gestão acadêmica e pedagógica no seu painel do Moodle.';
$string['welcome_title'] = 'Bem-vindo ao Kopere Dashboard!';
