<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Lang file
 *
 * @package   local_kopere_dashboard
 * @copyright 2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;
$string['about_description_text'] = 'Kopere Dashboard centralizes academic, financial, operational, and administrative routines in a single interface within Moodle.';
$string['about_description_title'] = 'About the plugin';
$string['about_github_label'] = 'GitHub';
$string['about_support_text'] = 'For documentation, source code, or project evolution, use the links below.';
$string['about_support_title'] = 'Useful links';
$string['about_website_label'] = 'Developer website';
$string['active'] = 'Active';
$string['audit'] = 'Audit log';
$string['audit_action'] = 'Action';
$string['audit_component'] = 'Component';
$string['audit_description'] = 'Description';
$string['audit_filter'] = 'Filter';
$string['audit_latest'] = 'Latest Activities (Audit)';
$string['audit_search'] = 'Search';
$string['audit_time'] = 'Time';
$string['audit_user'] = 'User';
$string['bi_course_details'] = 'Recent participant activity';
$string['bi_detail_name'] = 'Name';
$string['bi_global_reports_note'] = 'These are site-wide BI reports; they are not filtered to this user.';
$string['bi_metric_courses'] = 'Courses visited';
$string['bi_metric_lastaccess'] = 'Last recorded access';
$string['bi_metric_participants'] = 'Users with recorded access';
$string['bi_metric_time'] = 'Recorded time';
$string['bi_metric_visits'] = 'Recorded visits';
$string['bi_never_accessed'] = 'No recorded access';
$string['bi_reports_title'] = 'Related Kopere BI reports';
$string['bi_section_title'] = 'Kopere BI: learning analytics';
$string['bi_tracking_note'] = 'Figures are based on recorded Kopere BI tracking, not all Moodle activity.';
$string['bi_user_details'] = 'Recently accessed courses';
$string['cat_academic'] = 'Academic';
$string['cat_financial'] = 'Financial';
$string['cat_pedagogic'] = 'Pedagogical';
$string['cat_settings'] = 'Settings';
$string['cat_tools'] = 'Tools';
$string['chart_contracts_title'] = 'Contract Status';
$string['chart_enrollments_title'] = 'Enrollment Overview';
$string['contracts_expired'] = 'Expired';
$string['contracts_pending'] = 'Pending';
$string['contracts_signed'] = 'Signed';
$string['dashboard'] = 'Dashboard';
$string['datatables_buttons_copyKeys'] = 'Press <i>ctrl</i> or <i>\\u2318</i> + <i>C</i> to copy the table data<br>to your system clipboard.<br><br>To cancel, click this message or press escape.';
$string['datatables_buttons_copySuccess1'] = 'Copied one row to clipboard';
$string['datatables_buttons_copySuccess_'] = 'Copied %d rows to clipboard';
$string['datatables_buttons_copyTitle'] = 'Copy to clipboard';
$string['datatables_buttons_copy_text'] = 'Copy data';
$string['datatables_buttons_csv_text'] = 'Download CSV';
$string['datatables_buttons_pageLength_'] = 'Show %d items';
$string['datatables_buttons_pageLength_1'] = 'Show all';
$string['datatables_buttons_print_text'] = 'Print';
$string['datatables_buttons_select_rows1'] = '1 row selected';
$string['datatables_buttons_select_rows_'] = '%d rows selected';
$string['datatables_oAria_sSortAscending'] = ': Sorting Columns in ascending order';
$string['datatables_oAria_sSortDescending'] = ': Sorting columns in descending order';
$string['datatables_oPaginate_sFirst'] = 'First';
$string['datatables_oPaginate_sLast'] = 'Last';
$string['datatables_oPaginate_sNext'] = 'Next';
$string['datatables_oPaginate_sPrevious'] = 'Previous';
$string['datatables_sEmptyTable'] = 'No records found';
$string['datatables_sErrorMessage'] = '<strong>Error loading data</strong><div>Trying again in {$a} seconds</div>';
$string['datatables_sInfo'] = '_START_ to _END_ of _TOTAL_';
$string['datatables_sInfoEmpty'] = '0 records';
$string['datatables_sInfoFiltered'] = '(Filtered from _MAX_ records)';
$string['datatables_sInfoThousands'] = '.';
$string['datatables_sLengthMenu'] = '_MENU_ per page';
$string['datatables_sLoadingRecords'] = 'Loading ...';
$string['datatables_sProcessing'] = 'Processing ...';
$string['datatables_sSearch'] = 'Search';
$string['datatables_sZeroRecords'] = 'No records found';
$string['deleted_successfully'] = 'Deleted successfully';
$string['globalsettings'] = 'Global settings';
$string['help_title'] = 'Help';
$string['inactive'] = 'Inactive';
$string['integracaoroot'] = 'Integration';
$string['invisible'] = 'Hidden';
$string['js_completed'] = 'Completed';
$string['js_processing'] = 'Processing...';
$string['kopere_dashboard:managepermissions'] = 'Manage Kopere Dashboard permissions';
$string['kopere_dashboard:view'] = 'View Kopere Dashboard';
$string['kopere_dashboard:viewaudit'] = 'View Kopere Dashboard audit log';
$string['m1'] = '1 month';
$string['m2'] = '2 months';
$string['m3'] = '3 months';
$string['m4'] = '4 months';
$string['m5'] = '5 months';
$string['m6'] = '6 months';
$string['managekopere_dashboardplugins'] = 'Manage Kopere Dashboard plugins';
$string['managekopere_dashboardplugins_desc'] = 'Enable, disable, and organize the plugin order. The order defined here will also be used to build the Kopere Dashboard menus.';
$string['menu_about'] = 'About';
$string['menu_about_desc'] = 'Version information, useful links, and Kopere Dashboard details.';
$string['menu_close'] = 'Close menu';
$string['menu_navigation'] = 'Navigation menu';
$string['messageprovider:local_kopere_dashboard_messages'] = 'Send Notifications';
$string['movedown'] = 'Move down';
$string['moveup'] = 'Move up';
$string['notification_manager'] = 'Notification preferences';
$string['order'] = 'Order';
$string['permissions'] = 'Permissions';
$string['permissions_add'] = '← Add';
$string['permissions_current_users'] = 'Users with access';
$string['permissions_desc'] = 'This screen brings together the permissions for Kopere Dashboard and its plugins. Each block represents an available permission in the system and shows what users are allowed to do. When managing permissions, you can define who will have access to each action, organizing profiles according to the responsibility of each team, such as office staff, finance, coordination, or support. Use this area to carefully review access, avoiding granting permissions beyond what is necessary.';
$string['permissions_manage'] = 'Manage';
$string['permissions_potential_users'] = 'Users without access';
$string['permissions_remove'] = 'Remove →';
$string['permissions_users_desc'] = 'Use the selectors to add or remove users for this permission (role assignment in the system context).';
$string['php_security_notice_description'] = 'PHP {$a->version} predates the upstream fixed release {$a->fixedversion}. Two critical flaws can allow unauthenticated remote code execution. Update PHP and restart the PHP web workers. Linux vendors may backport patches without changing the upstream version number; verify your installed package.';
$string['php_security_notice_details'] = 'Read the official PHP advisory';
$string['php_security_notice_dismiss'] = 'Dismiss this warning for the current PHP version';
$string['php_security_notice_label'] = 'Critical security advisory - 21 October 2026';
$string['php_security_notice_title'] = 'Critical PHP security vulnerabilities';
$string['php_security_notice_unsupported_description'] = 'PHP {$a} is older than the maintained branches that received these security fixes. Upgrade to a supported, patched PHP release and restart web workers. Check your Linux distribution for security backports.';
$string['plugin_external'] = 'External plugin';
$string['pluginname'] = 'Kopere Dashboard';
$string['pluginstatus_activate'] = 'Activate';
$string['pluginstatus_active'] = 'Active';
$string['pluginstatus_deactivate'] = 'Deactivate';
$string['pluginstatus_inactive'] = 'Inactive';
$string['profile_enrol_active'] = 'Active';
$string['profile_enrol_expires'] = 'Expires on';
$string['profile_enrol_inactive'] = 'Inactive';
$string['profile_enrol_notexpires'] = 'No expiry date';
$string['profile_notenrol'] = 'User is not enrolled in any course.';
$string['reports'] = 'Reports';
$string['reports_export'] = 'Export';
$string['saved_successfully'] = 'Saved successfully';
$string['showmenu'] = 'Show menu';
$string['showmenu_desc'] = 'When enabled, Kopere Dashboard adds its link to the Moodle navigation and custom menu. When disabled, the navigation hook is ignored.';
$string['status'] = 'Status';
$string['student_courses_empty'] = 'You do not have any active courses to follow here yet.';
$string['student_courses_title'] = 'My courses';
$string['student_courses_title_desc'] = 'Open the full list of your courses.';
$string['student_kpi_completed_courses'] = 'Completed courses';
$string['student_kpi_completed_courses_sub'] = 'Already completed by you';
$string['student_kpi_enrolled_courses'] = 'Enrolled courses';
$string['student_kpi_enrolled_courses_sub'] = 'Total active courses at the moment';
$string['student_kpi_in_progress_courses'] = 'In progress';
$string['student_kpi_in_progress_courses_sub'] = 'Courses with recent activity';
$string['student_kpi_tracked_courses'] = 'With progress';
$string['student_kpi_tracked_courses_sub'] = 'Courses tracked by completion';
$string['student_lastaccess'] = 'Last access';
$string['student_never_accessed'] = 'Not accessed yet';
$string['student_progress'] = 'Progress';
$string['student_progress_not_available'] = 'Not available';
$string['student_quicklink_calendar'] = 'Calendar';
$string['student_quicklink_calendar_desc'] = 'View deadlines, events, and important activities.';
$string['student_quicklink_profile'] = 'My profile';
$string['student_quicklink_profile_desc'] = 'Review your personal information and preferences.';
$string['student_quicklinks_title'] = 'Quick shortcuts';
$string['student_status_completed'] = 'Completed';
$string['student_status_inprogress'] = 'In progress';
$string['student_status_notstarted'] = 'Not started';
$string['student_welcome_desc'] = 'Follow your courses, view your progress, and quickly resume what you need to study.';
$string['student_welcome_title'] = 'Your student dashboard';
$string['subplugintype_koperedashboard'] = 'Plugin';
$string['subplugintype_koperedashboard_plural'] = 'Plugins';
$string['visible'] = 'Visible';
$string['webpages_allpages'] = 'All pages';
$string['welcome_desc'] = 'The complete hub for academic and pedagogical management in your Moodle dashboard.';
$string['welcome_title'] = 'Welcome to Kopere Dashboard!';
